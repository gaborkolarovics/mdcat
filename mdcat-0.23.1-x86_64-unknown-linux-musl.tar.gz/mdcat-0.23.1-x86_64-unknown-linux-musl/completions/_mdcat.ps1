
using namespace System.Management.Automation
using namespace System.Management.Automation.Language

Register-ArgumentCompleter -Native -CommandName 'mdcat' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $commandElements = $commandAst.CommandElements
    $command = @(
        'mdcat'
        for ($i = 1; $i -lt $commandElements.Count; $i++) {
            $element = $commandElements[$i]
            if ($element -isnot [StringConstantExpressionAst] -or
                $element.StringConstantType -ne [StringConstantType]::BareWord -or
                $element.Value.StartsWith('-')) {
                break
        }
        $element.Value
    }) -join ';'

    $completions = @(switch ($command) {
        'mdcat' {
            [CompletionResult]::new('--columns', 'columns', [CompletionResultType]::ParameterName, 'Maximum number of columns to use for output')
            [CompletionResult]::new('-p', 'p', [CompletionResultType]::ParameterName, 'Paginate the output of mdcat with a pager like less.')
            [CompletionResult]::new('--paginate', 'paginate', [CompletionResultType]::ParameterName, 'Paginate the output of mdcat with a pager like less.')
            [CompletionResult]::new('-P', 'P', [CompletionResultType]::ParameterName, 'Do not page output.  Default if invoked as mdcat')
            [CompletionResult]::new('--no-pager', 'no-pager', [CompletionResultType]::ParameterName, 'Do not page output.  Default if invoked as mdcat')
            [CompletionResult]::new('-c', 'c', [CompletionResultType]::ParameterName, 'Disable all colours and other styles.')
            [CompletionResult]::new('--no-colour', 'no-colour', [CompletionResultType]::ParameterName, 'Disable all colours and other styles.')
            [CompletionResult]::new('-l', 'l', [CompletionResultType]::ParameterName, 'Do not load remote resources like images')
            [CompletionResult]::new('--local', 'local', [CompletionResultType]::ParameterName, 'Do not load remote resources like images')
            [CompletionResult]::new('--dump-events', 'dump-events', [CompletionResultType]::ParameterName, 'Dump Markdown parser events and exit')
            [CompletionResult]::new('--fail', 'fail', [CompletionResultType]::ParameterName, 'Exit immediately if any error occurs processing an input file')
            [CompletionResult]::new('--detect-only', 'detect-only', [CompletionResultType]::ParameterName, 'Only detect the terminal type and exit')
            [CompletionResult]::new('--ansi-only', 'ansi-only', [CompletionResultType]::ParameterName, 'Limit to standard ANSI formatting')
            [CompletionResult]::new('-h', 'h', [CompletionResultType]::ParameterName, 'Prints help information')
            [CompletionResult]::new('--help', 'help', [CompletionResultType]::ParameterName, 'Prints help information')
            [CompletionResult]::new('-V', 'V', [CompletionResultType]::ParameterName, 'Prints version information')
            [CompletionResult]::new('--version', 'version', [CompletionResultType]::ParameterName, 'Prints version information')
            break
        }
    })

    $completions.Where{ $_.CompletionText -like "$wordToComplete*" } |
        Sort-Object -Property ListItemText
}
